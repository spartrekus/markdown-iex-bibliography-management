

== TEXIEX MARKDOWN

=== v0.1:
   This is GNU made by Tomatoes
   Please use it or improve it.

=== About
This shows an example of tiny solutions of about 


=== Major dependencies
    gcc, ncurses devel  (cool no?)


=== Installation
          apt-get install --no-install-recommends texlive texlive-extra-utils texlive-latex-extra 
	  this is about 170 MB only !


