
Only this: 
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


Gives you: 
   strrlf     remove the line feed i.e. '\n'
   strcut     cut the string
   strsplit   split the cols with e.g. ';'
   strtex     add \ before &  or % 
   nruncmd     like system 
   ncruncmd    like system (under ncurses)
   strbraket   get item between { and }


