
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
// texiex.c  // IeX to TeX Converter
///////////////////////////////////////////////////////////////////
// Made by GNU Linux 
// Author: Tomatoes
///////////////////////////////////////////////////////////////////
#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <string.h>
///////////////////////////////////
#include <ctype.h>  // fexist
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
///////////////////////////////////
#include <unistd.h>  //define getcwd
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h> //
// for fexist
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>  //define getcwd
// time 
#include <time.h>



/// C based libraries (no ncurses)
#include "../libc/libc-key.c"
#include "../libc/libc-str.c"
#include "../libc/libc-bin.c"

// global
int citearticle_mode = 0; 
int sectionnbr    = 0;
int subsectionnbr = 0;


/////////////////////////////////////
void filenew( char *fileout)
{
    FILE *fp5;
    fp5 = fopen( fileout , "wb+");
    fclose( fp5 );
}




/////////////////////////////////////
void filearticle_newlist( char *fileout)
{
    FILE *fp5;
    fp5 = fopen( fileout , "wb+");
    fclose( fp5 );
}
void filearticle_newbbl( char *fileout )
{
    FILE *fp5;
    if ( citearticle_mode >= 1 ){
    }
}




void fileclosertf( char *fileout)
{
     FILE *fp5;
     // close the rtf
     fp5 = fopen( fileout , "ab+"); 
	 fputs( "\\par }\n", fp5 );
     fclose( fp5 );
}






//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
///// make the iexarticlelist.lst !! (once an item article!!)
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
char *dbfindarticle( char *myart )
{
   FILE *fpcheck;
   FILE *fp9;
   char fp9linetmp[PATH_MAX];
   char fp9line[PATH_MAX];
   int founditem = 0; 
   char fp9out[PATH_MAX];
   char charo[PATH_MAX];
   strncpy( fp9out, "", PATH_MAX );
   int taki;
   char takiline[PATH_MAX];
   strncpy( takiline, "", PATH_MAX );
   char takilinetmp[PATH_MAX];
   strncpy( takilinetmp, "", PATH_MAX );
   char referencelineout[PATH_MAX];
   strncpy( referencelineout, "", PATH_MAX );
   char buffer[PATH_MAX];
   strncpy( buffer, "", PATH_MAX );
   char buffer_author[PATH_MAX];
   char buffer_journal[PATH_MAX];
   char buffer_issue[PATH_MAX];
   char buffer_title[PATH_MAX];
   char buffer_year[PATH_MAX];
   char buffer_vol[PATH_MAX];
   char buffer_pages[PATH_MAX];
   int  ficheread = 1;

   char dbfile[PATH_MAX];
   strncpy( dbfile, "", PATH_MAX );
   strncat( dbfile , getenv( "HOME" ) , PATH_MAX - strlen( dbfile ) - 1);
   strncat( dbfile , "/references.bib" , PATH_MAX - strlen( dbfile ) - 1);

   printf( "Search : %s\n" , myart );
   if ( fexist( dbfile ) == 1 )
   {
    fp9 = fopen( dbfile , "rb");
    while( !feof(fp9) && ( founditem == 0 ) ) 
    {
          fgets( fp9linetmp, PATH_MAX, fp9); 
          strncpy( fp9line , strrlf( fp9linetmp ) , PATH_MAX );
          if ( !feof(fp9) )
	  if ( founditem == 0 )
          {
	      if ( founditem == 0 )
	      if( strstr( fp9line , myart ) != 0 ) 
	      {
	         founditem = 1;
                 strncpy( takilinetmp , "", PATH_MAX );
                 strncpy( takiline , "", PATH_MAX );
                 strncpy( referencelineout, "", PATH_MAX );
                 strncpy( buffer, "", PATH_MAX );
                 strncpy( buffer_title, "", PATH_MAX );
                 strncpy( buffer_year, "", PATH_MAX );
                 strncpy( buffer_author, "", PATH_MAX );
                 strncpy( buffer_journal, "", PATH_MAX );
                 strncpy( buffer_vol, "", PATH_MAX );
                 strncpy( buffer_pages, "", PATH_MAX );
                 strncpy( buffer_issue, "", PATH_MAX );
                 ficheread = 1;

		 while( ficheread == 1 )
		 {
                    fgets( takilinetmp , PATH_MAX, fp9); 
                    strncpy( takiline,  strrlf( takilinetmp ) , PATH_MAX );
                    printf( "|%s|\n", takiline);

		    if ( takiline[0] == '}' ) ficheread = 0;

		    if( ficheread == 1)
		    if(!feof( fp9 ))
		    {

		    if ( takiline[0] == 'a' )
		    if ( takiline[1] == 'u' )
		    if ( strstr( takiline, "author =" ) != 0 ) 
		    {
		       strncpy( charo , strtex( strsplit( strrlf( takiline ), '"', 2 )) , PATH_MAX );
                       strncpy( buffer,  ""  , PATH_MAX );
                       strncat( buffer , charo , PATH_MAX - strlen( buffer ) - 1);
                       strncat( buffer , ", " , PATH_MAX - strlen(buffer) - 1);
		       strncpy( buffer_author, buffer , PATH_MAX );
		    }

		    if ( takiline[0] == 'j' )
		    if ( takiline[1] == 'o' )
		    if ( strstr( takiline, "journal =" ) != 0 ) 
		    {
		       strncpy( charo , strtex( strsplit( strrlf( takiline ), '"', 2 )), PATH_MAX );
                       strncpy( buffer,  ""  , PATH_MAX );
                       strncat( buffer , charo , PATH_MAX - strlen(buffer) - 1);
                       strncat( buffer , ", " , PATH_MAX - strlen(buffer) - 1);
		       strncpy( buffer_journal, buffer , PATH_MAX );
		    }


		    if ( takiline[0] == 't' )
		    if ( takiline[1] == 'i' )
		    if ( strstr( takiline, "title =" ) != 0 ) 
		    {
		       strncpy( charo , strtex( strsplit( strrlf( takiline ), '"', 2 )), PATH_MAX );
                       strncpy( buffer,  ""  , PATH_MAX );
                       strncat( buffer , "\"" , PATH_MAX - strlen(buffer) - 1);
                       strncat( buffer , charo , PATH_MAX - strlen(buffer) - 1);
                       strncat( buffer , "\"" , PATH_MAX - strlen(buffer) - 1);
                       strncat( buffer , ", " , PATH_MAX - strlen(buffer) - 1);
		       strncpy( buffer_title, buffer , PATH_MAX );
		    }

		    if ( takiline[0] == 'p' )
		    if ( takiline[1] == 'a' )
		    if ( strstr( takiline, "pages =" ) != 0 ) 
		    {
		       strncpy( charo , strtex( strsplit( strrlf( takiline ), '"', 2 )), PATH_MAX );
                       strncpy( buffer,  ""  , PATH_MAX );
                       strncat( buffer , "pp. " , PATH_MAX - strlen(buffer) - 1);
                       strncat( buffer , charo , PATH_MAX - strlen(buffer) - 1);
                       strncat( buffer , ". " , PATH_MAX - strlen(buffer) - 1);
		       strncpy( buffer_pages, buffer , PATH_MAX );
		    }

		    if ( takiline[0] == 'v' )
		    if ( takiline[1] == 'o' )
		    if ( strstr( takiline, "volume =" ) != 0 ) 
		    {
		       strncpy( charo , strtex( strsplit( strrlf( takiline ), '"', 2 )), PATH_MAX );
                       strncpy( buffer,  "vol. "  , PATH_MAX );
                       strncat( buffer , charo , PATH_MAX - strlen(buffer) - 1);
                       strncat( buffer , ", " , PATH_MAX - strlen(buffer) - 1);
		       strncpy( buffer_vol, buffer , PATH_MAX );
		    }



		    if ( takiline[0] == 'y' )
		    if ( takiline[1] == 'e' )
		    if ( takiline[2] == 'a' )
		    if ( strstr( takiline, "year =" ) != 0 ) 
		    {
                       strncpy( buffer,  ""  , PATH_MAX );
		       strncpy( charo , strtex( strsplit( strrlf( takiline ), '"', 2 )), PATH_MAX );
                       strncat( buffer , charo , PATH_MAX - strlen(buffer) - 1);
                       strncat( buffer , ", " , PATH_MAX - strlen(buffer) - 1);
		       strncpy( buffer_year, buffer , PATH_MAX );
		    }


		   }

                   strncpy( fp9out,  ""  , PATH_MAX );
                   strncat( fp9out , buffer_author , PATH_MAX - strlen(fp9out) - 1);
                   strncat( fp9out , buffer_title , PATH_MAX - strlen(fp9out) - 1);
                   strncat( fp9out , buffer_journal , PATH_MAX - strlen(fp9out) - 1);
                   strncat( fp9out , buffer_vol , PATH_MAX - strlen(fp9out) - 1);
                   strncat( fp9out , buffer_year , PATH_MAX - strlen(fp9out) - 1);
                   strncat( fp9out , buffer_pages , PATH_MAX - strlen(fp9out) - 1);

		  }

	      }

	  }
     }
     fclose( fp9 );
    }
    else
    {
      printf( "database not found\n" );
    }

    size_t siz = sizeof fp9out ; 
    char *r = malloc( sizeof fp9out );
    return r ? memcpy(r, fp9out, siz ) : NULL;
}












///////////////////////////////////////////////////////////////////
void filerawcat(  char *fileout, char *filein ){
  int fetchi;
  FILE *fp5;
  FILE *fp6;

  char fetchline[PATH_MAX];
  char fetchlinetmp[PATH_MAX];
  /////////////////////////////////////////////////
  if ( fexist( filein ) == 1 )
  {
    fp5 = fopen( fileout , "ab+");
    fp6 = fopen( filein , "rb");
    while( !feof(fp6) ) 
    {
          fgets(fetchlinetmp, PATH_MAX, fp6); 
          strncpy( fetchline, "" , PATH_MAX );
          for( fetchi = 0 ; ( fetchi <= strlen( fetchlinetmp ) ); fetchi++ )
            if ( fetchlinetmp[ fetchi ] != '\n' )
              fetchline[fetchi]=fetchlinetmp[fetchi];

         if ( !feof(fp6) )
         {
 	      fputs( fetchline , fp5 );
  	      fputs( "\n", fp5 );
	 }
     }
     fclose( fp5 );
     fclose( fp6 );
   }
}









///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
/////////////////// M A I N ///////////////////////////////////////
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
void filetexiex( char *fileout, char *filein ){
  int fetchi;
  int i , j , k ; 
  FILE *fp6;

  FILE *fpbbl;
  fpbbl = fopen( "iexreferences.bbl" , "wb+"); 
    fputs( "\\begin{thebibliography}{9}\n", fpbbl );
  fclose( fpbbl );


  char charo[PATH_MAX];
  char fetchline[PATH_MAX];
  char fetchlinetmp[PATH_MAX];
  int foundcode = 0;
  int foundlinefeed = 0;
  int commenton = 0;
  int fpreader = 1;

  char templatefile[PATH_MAX];
  char lineout[PATH_MAX];
  strncpy( templatefile, "", PATH_MAX );
  char citearticle_ref[PATH_MAX];
  strncpy( citearticle_ref, "", PATH_MAX );

  //////////////////////////
  //////////////////////////
  //////////////////////////
  void addlinefeed()
  {
  }

  /////////////////////////////////////////////////
  if ( fexist( filein ) == 1 )
  {
    fp6 = fopen( filein , "r");
    while ( ( !feof(fp6) ) &&  ( fpreader == 1 ) )
    {
          fgets(fetchlinetmp, PATH_MAX, fp6); 
          strncpy( fetchline, "" , PATH_MAX );
          foundcode = 0;

          strncpy( lineout, "" , PATH_MAX );
          strncpy( fetchline, "" , PATH_MAX );
          /// remove lf
          for( fetchi = 0 ; ( fetchi <= strlen( fetchlinetmp ) ); fetchi++ )
            if ( fetchlinetmp[ fetchi ] != '\n' )
              fetchline[fetchi]=fetchlinetmp[fetchi];

           if ( ( !feof(fp6) ) &&  ( fpreader == 1 ) )
           {
                  printf( "Reference: %s\n", fetchline );
                  strncpy( lineout, dbfindarticle( fetchline ) , PATH_MAX );
                  printf( "Returns: %s\n",  lineout );
                  printf( "%s\n" );
                  if ( strcmp( lineout, "" ) != 0 ) 
		  {
                    fpbbl = fopen( "iexreferences.bbl" , "ab+"); 
	              fputs( "\\bibitem{" , fpbbl );
	              fputs( fetchline , fpbbl );
	              fputs( "} " , fpbbl );
	              fputs( lineout , fpbbl );
	              fputs( "\n", fpbbl );
                    fclose( fpbbl );
		  }
  	   }
     }
     fclose( fp6 );
   }



  fpbbl = fopen( "iexreferences.bbl" , "ab+"); 
    fputs( "\\end{thebibliography}\n", fpbbl );
    fputs( "\n", fpbbl );
  fclose( fpbbl );

}











//////// MAIN 
int main( int argc, char *argv[])
{ 
    char cwd[PATH_MAX];
    char targetfile[PATH_MAX];


    ////////////////////////////////////////////////////////
    if ( argc == 2)
      if ( strcmp( argv[1] , "--env" ) ==  0 ) 
      {
          printf( "HOME:|%s|\n", getenv( "HOME" ) );
          return 0;
      }



    ////////////////////////////////////////////////////////
    if ( argc == 3)
      if ( strcmp( argv[1] , "--find" ) ==  0 ) 
      if ( strcmp( argv[2] , "" ) !=  0 ) 
      {
          strncpy( cwd, dbfindarticle( argv[ 2 ] ) , PATH_MAX );
          printf( "%s\n", cwd );
          return 0;
      }



    filetexiex( "iexreferences.bbl", "iexarticlelist.lst" );
    return 0;
}




