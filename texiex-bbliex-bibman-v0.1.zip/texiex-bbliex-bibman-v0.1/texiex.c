
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
// texiex.c  // IeX to TeX Converter
///////////////////////////////////////////////////////////////////
// Made by GNU Linux 
// Author: Tomatoes
///////////////////////////////////////////////////////////////////
#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <string.h>
///////////////////////////////////
#include <ctype.h>  // fexist
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
///////////////////////////////////
#include <unistd.h>  //define getcwd
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h> //
// for fexist
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>  //define getcwd
// time 
#include <time.h>

/// C based libraries (no ncurses)
#include "../libc/libc-key.c"
#include "../libc/libc-str.c"
#include "../libc/libc-bin.c"


// global
int citearticle_mode = 0; 
int sectionnbr    = 0;
int subsectionnbr = 0;



/////////////////////////////////////
void filenew( char *fileout)
{
    FILE *fp5;
    fp5 = fopen( fileout , "wb+");
    fclose( fp5 );
}





/////////////////////////////////////
void filearticle_newlist( char *fileout)
{
    FILE *fp5;
    fp5 = fopen( fileout , "wb+");
    fclose( fp5 );
}
void filearticle_newbbl( char *fileout )
{
    FILE *fp5;
    if ( citearticle_mode >= 1 ){
    }
}




void fileclosertf( char *fileout)
{
     FILE *fp5;
     // close the rtf
     fp5 = fopen( fileout , "ab+"); 
	 fputs( "\\par }\n", fp5 );
     fclose( fp5 );
}


///////////////////////////////////////////////////////////////////
void filerawcat(  char *fileout, char *filein ){
  int fetchi;
  FILE *fp5;
  FILE *fp6;
  char fetchline[PATH_MAX];
  char fetchlinetmp[PATH_MAX];



  /////////////////////////////////////////////////
  if ( fexist( filein ) == 1 )
  {
    fp5 = fopen( fileout , "ab+");
    fp6 = fopen( filein , "rb");
    while( !feof(fp6) ) 
    {
          fgets(fetchlinetmp, PATH_MAX, fp6); 
          strncpy( fetchline, "" , PATH_MAX );
          for( fetchi = 0 ; ( fetchi <= strlen( fetchlinetmp ) ); fetchi++ )
            if ( fetchlinetmp[ fetchi ] != '\n' )
              fetchline[fetchi]=fetchlinetmp[fetchi];

         if ( !feof(fp6) )
         {
 	      fputs( fetchline , fp5 );
  	      fputs( "\n", fp5 );
	 }
     }
     fclose( fp5 );
     fclose( fp6 );
   }
}





///// make the iexarticlelist.lst !! (once an item article!!)
void fpcitecheckwrite( char *myart )
{
   FILE *fpcheck;
   FILE *fp9;
   char fp9linetmp[PATH_MAX];
   char fp9line[PATH_MAX];
   int founditem = 0; 

   if ( citearticle_mode == 0 ) filearticle_newlist( "iexarticlelist.lst" );
   citearticle_mode++;
   if ( fexist( "iexarticlelist.lst" ) == 1 )
   {
    fp9 = fopen( "iexarticlelist.lst" , "rb");
    while( !feof(fp9) ) 
    {
          fgets( fp9linetmp, PATH_MAX, fp9); 
          strncpy( fp9line , strrlf( fp9linetmp ) , PATH_MAX );
          if ( !feof(fp9) )
	  if ( founditem == 0 )
          {
	      if( strstr( fp9linetmp, myart ) != 0 ) 
	      {
	         founditem = 1;
	      }
	  }
     }
     fclose( fp9 );
    }

    if ( founditem == 0 )
    { 
        fpcheck = fopen( "iexarticlelist.lst" , "ab+");
  	      fputs( myart , fpcheck );
  	      fputs( "\n", fpcheck );
	fclose( fpcheck );
    }
}








///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
/////////////////// M A I N 
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
void filetexiex( char *fileout, char *filein ){
  int fetchi;
  int i , j , k ; 
  FILE *fp5;
  FILE *fp6;
  FILE *foofp;
  FILE *fpcite;

  char charo[PATH_MAX];
  char fetchline[PATH_MAX];
  char fetchlinetmp[PATH_MAX];
  int foundcode = 0;
  int foundlinefeed = 0;
  int commenton = 0;
  int fpreader = 1;

  char templatefile[PATH_MAX];
  strncpy( templatefile, "", PATH_MAX );

  char citearticle_ref[PATH_MAX];
  strncpy( citearticle_ref, "", PATH_MAX );

  //////////////////////////
  //////////////////////////
  //////////////////////////
  void addlinefeed()
  {
        // fputs( "\\\\" , fp5 );
  }


  /////////////////////////////////////////////////
  if ( fexist( filein ) == 1 )
  {
    fp5 = fopen( fileout , "ab+");
    fp6 = fopen( filein , "r");
    while ( ( !feof(fp6) ) &&  ( fpreader == 1 ) )
    {
          fgets(fetchlinetmp, PATH_MAX, fp6); 
          strncpy( fetchline, "" , PATH_MAX );
          foundcode = 0;

          /// remove lf
          for( fetchi = 0 ; ( fetchi <= strlen( fetchlinetmp ) ); fetchi++ )
            if ( fetchlinetmp[ fetchi ] != '\n' )
              fetchline[fetchi]=fetchlinetmp[fetchi];




         if ( ( !feof(fp6) ) &&  ( fpreader == 1 ) )
         {


            if ( strstr( fetchline , "\\cite{"  ) != 0 )
	    {
                 strncpy( citearticle_ref, "", PATH_MAX );
                 strncat( citearticle_ref , strbraket( fetchline ) , PATH_MAX - strlen( citearticle_ref ) -1 );
   	         fpcitecheckwrite( citearticle_ref );
	    }


            /////////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '/' )
            if ( fetchline[1] == '/' )
            {
  	      foundcode = 1;
            }

            /////////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '/' )
            if ( fetchline[1] == '*' )
            {
  	      commenton = 1;
            }

            if ( foundcode == 0 )
            if ( fetchline[0] == '*' )
            if ( fetchline[1] == '/' )
            {
  	      commenton = 0;
    	      foundcode = 1;
            }

            if ( commenton == 1 )
            {
    	      foundcode = 1;
            }
            /////////////////////////////////////
            /////////////////////////////////////

            if ( foundcode == 0 )
            if ( fetchline[0] == '/' )
            if ( fetchline[1] == '/' )
            {
  	        foundcode = 1;
  	        foundcode = 1;
            }

            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'r' )
            if ( fetchline[3] == 'e' )
            if ( fetchline[4] == 'a' )
            if ( fetchline[5] == 'k' )
            {
  	      fpreader = 0;
  	      foundcode = 1;
            }
            /////////////////////////////////////
            /////////////////////////////////////




            // $linefeed
	    //////////////////////////////////
            if ( foundcode == 0 )
            if ( strcmp(fetchline, "" ) == 0 )
            {
  	        fputs( "\n", fp5 );
                //foundlinefeed = 1;
  	        foundcode = 1;
            }


            // $green 
            // to do 


            // $bold 
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'l' )
            if ( fetchline[4] == 'd' )
            if ( fetchline[5] == ' ' )
            {
 	      fputs( "\\iexbold{" , fp5 );
 	      fputs( strcut( fetchline , 7, strlen(fetchline) ) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }



            // $ital 
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 't' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'l' )
            if ( fetchline[5] == ' ' )
            {
 	      fputs( "\\iexital{" , fp5 );
 	      //fputs( strcut( fetchline, 7, strlen(fetchline)-1) , fp5 );
 	      fputs( strcut( fetchline , 7, strlen(fetchline) ) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }

            // $blue
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'l' )
            if ( fetchline[3] == 'u' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == ' ' )
            {
 	      fputs( "\\iexblue{" , fp5 );
 	      //fputs( strcut( fetchline, 7, strlen(fetchline)-1) , fp5 );
 	      //fputs( strrlf(fetchline ) , fp5 );
 	      fputs( strcut( fetchline , 7, strlen(fetchline) ) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }


            // $pdf
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'p' )
            if ( fetchline[2] == 'd' )
            if ( fetchline[3] == 'f' )
            if ( fetchline[4] == '{' )
            {
 	      fputs( "\\iexpdf{" , fp5 );
 	      fputs( strbraket( fetchline ) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }



            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == 'p' )
            if ( fetchline[4] == 'u' )
            if ( fetchline[5] == 't' )
            if ( fetchline[6] == '{' )
            {
 	      fputs( "\n" , fp5 );
 	      fputs( "%%INPUTFILE{" , fp5 );
 	      fputs( strbraket( fetchline ) , fp5 );
 	      fputs( "}\n" , fp5 );
              fclose( fp5 );                 /// writer
              long saved = ftell( fp6 );     /// reader
              fclose( fp6 );                 /// reader
                filetexiex( fileout, strbraket( fetchline ) );
              fp5 = fopen( fileout , "ab+"); /// writer
              fp6 = fopen( filein , "r");  /// reader
              fseek( fp6 , saved , SEEK_SET); // reader 
  	      foundcode = 1;
              foundlinefeed = 0;
            }
	    
            // include iexdoc from lib!!
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == 'c' )
            if ( fetchline[4] == 'l' )
            if ( fetchline[5] == 'u' )
            if ( fetchline[6] == 'd' )
            if ( fetchline[7] == 'e' )
            if ( fetchline[8] == '{' )
            {
              strncpy( templatefile, "/usr/share/iexdoc/lib/", PATH_MAX );
              strncat( templatefile , strbraket( fetchline ) , PATH_MAX - strlen( templatefile ) -1 );
              if ( strcmp( templatefile, "" ) != 0 )
              if ( fexist( templatefile ) == 1 )
              {
    	         fputs( "\n" , fp5 );
    	         fputs( "%%INCLUDEFILE{" , fp5 );
    	         fputs( templatefile , fp5 );
    	         fputs( "}\n" , fp5 );
                 fclose( fp5 );                 /// writer
                 long saved = ftell( fp6 );     /// reader
                 fclose( fp6 );                 /// reader
                   filetexiex( fileout,  templatefile  );
                 fp5 = fopen( fileout , "ab+"); /// writer
                 fp6 = fopen( filein , "r");  /// reader
                 fseek( fp6 , saved , SEEK_SET); // reader 
              }
  	      foundcode = 1;
              foundlinefeed = 0;
            }



            // end the document cleanly 
            if ( foundcode == 0 )
            if ( strcmp( fetchline , "$enddoc" ) == 0 )
            {
  	      fputs( "\\end{document}\n", fp5 );
              foundlinefeed = 0;
  	      foundcode = 1;
            }




            // $fig
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == '{' )
            {
 	      fputs( "\\iexfig{" , fp5 );
 	      fputs( strbraket( fetchline ) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }
	    

            // iexlineitalic
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 't' )
            if ( fetchline[3] == ' ' )
            {
 	      fputs( "\\iexlineitalic{" , fp5 );
 	      fputs( strcut( fetchline , 6-1, strlen(fetchline) ) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }



            // tor
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 't' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'r' )
            {
 	      fputs( "\\iextor" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }







            if ( foundcode == 0 )
            if ( fetchline[0] == '#' )
            {
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }




            // iexline (alternative)
            if ( foundcode == 0 )
            if ( fetchline[0] == '|' )
            {
 	      fputs( "\\iexline{" , fp5 );
 	      fputs( strcut( fetchline , 0+2, strlen(fetchline) ) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }



            // smallskip
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 's' )
            if ( fetchline[2] == 'm' )
            if ( fetchline[3] == 's' )
            {
 	      fputs( "\\iexsmallskip" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }
            // bigskip
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'm' )
            if ( fetchline[3] == 's' )
            {
 	      fputs( "\\iexbigskip" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }





            // $red
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'r' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'd' )
            if ( fetchline[4] == ' ' )
            {
 	      fputs( "\\iexred{" , fp5 );
 	      fputs( strcut( fetchline , 6, strlen(fetchline) ) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }

    //////////////////////////////////////////////////////
    //////////////////////////////////////////////////////
    //////////////////////////////////////////////////////
    //////////////////////////////////////////////////////

            // $clr
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'c' )
            if ( fetchline[2] == 'l' )
            if ( fetchline[3] == 'r' )
            {
 	      fputs( "\\iexclr\n" , fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }


            // $background
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'c' )
            if ( fetchline[3] == 'k' )
            if ( fetchline[4] == 'g' )
            if ( fetchline[5] == 'r' )
            if ( fetchline[6] == 'd' )
            {
 	      fputs( "\\iexbackground\n" , fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }






            /// abstract
            if ( foundcode == 0 )
            if ( fetchline[0] == '>' )
            if ( fetchline[1] == ' ' )
            {
	      addlinefeed();
 	      fputs( "\\iexfleche{" , fp5 );
 	      fputs( strcut( fetchline , 3, strlen(fetchline) ) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
	      addlinefeed();
  	      foundcode = 1;
              foundlinefeed = 0;
            }



            /// new line
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'l' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == ' ' )
            {
 	      fputs( "\\iexline{" , fp5 );
 	      fputs( strcut( fetchline, 5, strlen(fetchline)) , fp5 );
  	      fputs( "}\n", fp5 );
	      //addlinefeed();
  	      foundcode = 1;
              foundlinefeed = 0;
            }

            // $im or new item
            if ( foundcode == 0 )
            if ( fetchline[0] == '*' )
            if ( fetchline[1] == ' ' )
            {
 	      fputs( "\\iexbullet{" , fp5 );
 	      fputs( strcut( fetchline, 3, strlen(fetchline)) , fp5 );
  	      fputs( "}\n", fp5 );
	      addlinefeed();
  	      foundcode = 1;
              foundlinefeed = 0;
            }
            // $im or new item
            if ( foundcode == 0 )
            if ( fetchline[0] == '-' )
            if ( fetchline[1] == ' ' )
            {
 	      fputs( "\\iexitem{" , fp5 );
 	      fputs( strcut( fetchline, 3, strlen(fetchline)) , fp5 );
  	      fputs( "}\n", fp5 );
	      addlinefeed();
  	      foundcode = 1;
              foundlinefeed = 0;
            }



            // $im or new item
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 'm' )
            if ( fetchline[3] == ' ' )
            {
	      addlinefeed();
 	      fputs( "\\iexitem{" , fp5 );
 	      fputs( strcut( fetchline, 5, strlen(fetchline)) , fp5 );
  	      fputs( "}\n", fp5 );
	      addlinefeed();
  	      foundcode = 1;
              foundlinefeed = 0;
            }



            // reader comments $com
            if ( foundcode == 0 )
            if ( fetchline[0] == '$' )
            if ( fetchline[1] == 'c' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'm' )
            if ( fetchline[4] == ' ' )
            {
 	      fputs( "{\\iexcomment{" , fp5 );
 	      fputs( strcut( fetchline, 6, strlen(fetchline)) , fp5 );
  	      fputs( "} ", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }

            // reader par / new line / new paragraph
            if ( foundcode == 0 )
            if ( strcmp( fetchline , "$par" ) == 0 )
            {
	      addlinefeed();
  	      fputs( "\n", fp5 );
              foundlinefeed = 0;
  	      foundcode = 1;
  	      foundcode = 1;
            }





            // $section 
            if ( foundcode == 0 )
            if ( fetchline[0] == '=' )
            if ( fetchline[1] == '=' )
            if ( fetchline[2] == ' ' )
            {
	      addlinefeed();
 	      fputs( "\\iexsection{" , fp5 );
              //j = snprintf( charo, 25 , "%d.%d. ", sectionnbr, ++subsectionnbr );
 	      fputs( strcut( fetchline, 4, strlen(fetchline)) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
	      addlinefeed();
  	      foundcode = 1;
              foundlinefeed = 0;
            }

            // $subsection 
            if ( foundcode == 0 )
            if ( fetchline[0] == '=' )
            if ( fetchline[1] == '=' )
            if ( fetchline[2] == '=' )
            if ( fetchline[3] == ' ' )
            {
	      addlinefeed();
 	      fputs( "\\iexsubsection{" , fp5 );
              j = snprintf( charo, 15 , "%d. ", ++sectionnbr );
 	      fputs( strcut( fetchline, 5, strlen(fetchline)) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
	      addlinefeed();
  	      foundcode = 1;
              foundlinefeed = 0;
              subsectionnbr = 0;
            }


  	    if ( foundcode == 0 )
  	    if ( strcmp( fetchline, "" ) != 0 )
            {
 	      fputs( fetchline , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
              foundlinefeed = 0;
            }

	 }
     }
     fclose( fp6 );
     fclose( fp5 );

   }
}





//////// MAIN 
int main( int argc, char *argv[])
{ 
    char cwd[PATH_MAX];
    char targetfile[PATH_MAX];



    ////////////////////////////////////////////////////////
    if ( argc == 3)
     if ( strcmp( argv[1] , "make" ) ==  0 ) 
     if ( fexist( argv[2] ) == 1 ) 
     if ( strcmp( fextension( argv[2] ) , "iex" ) ==  0 ) 
     {
          strncpy( targetfile, filename_newext( argv[2], "tex" ) , PATH_MAX );
          printf( "Convert from %s to %s\n", argv[2] , targetfile );
          filenew( targetfile );
          filetexiex( targetfile , argv[2] ); // make the tex
          if ( fexist( "iexarticlelist.lst" ) == 1 ) 
	    if ( fexist( "bbliex" ) == 1 )  nruncmd( " ./bbliex " ); else nruncmd( "bbliex " );
	  nrunwith( " pdflatex ", filename_newext( argv[2], "tex" ));
	  nrunwith( " mupdf ",    filename_newext( argv[2], "pdf" ));
          return 0;
     }



    ////////////////////////////////////////////////////////
    if ( argc == 2)
     if ( fexist( argv[1] ) == 1 ) 
     if ( strcmp( fextension( argv[1] ) , "iex" ) ==  0 ) 
     {
          strncpy( targetfile, filename_newext( argv[1], "tex" ) , PATH_MAX );
          printf( "Convert from %s to %s\n", argv[1] , targetfile );
          filenew( targetfile );
          filetexiex( targetfile , argv[1] );
          if ( fexist( "iexarticlelist.lst" ) == 1 )
	    if ( fexist( "bbliex" ) == 1 )  nruncmd( " ./bbliex " ); else nruncmd( " bbliex " );
          return 0;
     }



    ////////////////////////////////////////////////////////
    if ( argc == 2)
     if ( strcmp( argv[1] , "" ) !=  0 ) 
     {
	    printf( "Target not found \n" );
	    return 0; 
     }

     return 0;
}



